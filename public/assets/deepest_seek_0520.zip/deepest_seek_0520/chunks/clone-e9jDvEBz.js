import{b as r}from"./_baseUniq-Cvv2KAVM.js";var e=4;function a(o){return r(o,e)}export{a as c};
