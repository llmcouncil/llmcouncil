import{b as r}from"./browser-BwCE-VvP.js";const o=r.runtime.getURL("/app.html");console.log(o);window.open(o);
