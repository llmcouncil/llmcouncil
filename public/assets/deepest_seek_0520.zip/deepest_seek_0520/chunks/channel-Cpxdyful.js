import{ar as o,as as s}from"./app-DLhlTbWO.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
